/* =====================================================================
   auth.js — Appwrite authentication
   ---------------------------------------------------------------------
   The app's UI (index.html) only exposes phone-number + SMS OTP login/
   sign-up, plus a phone-OTP-based "Forgot password" reset flow — that's
   the entire user-facing auth surface now. Email/password and email-OTP
   methods below are kept as available Appwrite helpers (harmless, unused
   by the UI) in case a future admin/back-office screen needs them; they
   are intentionally not wired into any button in index.html.

   Session rules:
     - 8-char minimum password (validated client-side; also set this as
       the minimum in Appwrite Console > Auth > Security)
     - 30-day session length     -> set in Appwrite Console > Auth >
       Session Length (this is a project-level Console setting, not
       something the Web SDK can override per-call)
     - Max 4 concurrent sessions -> set in Appwrite Console > Auth >
       Session Limit
     - Force logout everywhere when password changes -> handled below
       by calling deleteSessions() right after updatePassword()
===================================================================== */

const ShortTubeAuth = {

  /* ---------------- Email + Password ---------------- */
  async registerWithEmail(email, password, displayName) {
    if (password.length < 8) throw new Error("Password must be at least 8 characters.");
    const user = await account.create(ID.unique(), email, password, displayName);
    await this.loginWithEmail(email, password);
    await ensureProfileDocument(user.$id, displayName);
    return user;
  },

  async loginWithEmail(email, password) {
    return account.createEmailPasswordSession(email, password);
  },

  /* ---------------- Email OTP (magic-code style) ---------------- */
  // Step 1: request a code, emailed to the user
  async requestEmailOTP(email) {
    // userId ID.unique() creates the user record on first OTP if it doesn't exist
    return account.createEmailToken(ID.unique(), email);
  },
  // Step 2: user enters the code they received
  async verifyEmailOTP(userId, secret) {
    const session = await account.createSession(userId, secret);
    // BUG FIX: email/password signup was the only path that created a profile
    // document (via ensureProfileDocument). Anyone who logged in via Email OTP
    // never got one, so their Profile page/stats silently failed forever.
    const user = await account.get();
    await ensureProfileDocument(user.$id, user.name || user.email || "ShortTube User");
    return session;
  },

  /* ---------------- Phone (SMS) OTP ---------------- */
  async requestPhoneOTP(phoneNumberE164) {
    // e.g. "+14155552671"
    return account.createPhoneToken(ID.unique(), phoneNumberE164);
  },
  async verifyPhoneOTP(userId, secret) {
    const session = await account.createSession(userId, secret);
    // Same fix as verifyEmailOTP above — phone sign-in needs a profile doc too.
    const user = await account.get();
    await ensureProfileDocument(user.$id, user.name || user.phone || "ShortTube User");
    return session;
  },

  /* ---------------- Password change -> force logout everywhere ---------------- */
  async changePassword(newPassword, oldPassword) {
    if (newPassword.length < 8) throw new Error("Password must be at least 8 characters.");
    await account.updatePassword(newPassword, oldPassword);
    // Kill every other active session (all devices) as required
    await account.deleteSessions();
    // Re-establish a fresh session on this device only if you want to keep the user logged in here;
    // otherwise just redirect to the login screen.
  },

  /* ---------------- Session helpers ---------------- */
  async getCurrentUser() {
    try { return await account.get(); }
    catch (err) { return null; } // not logged in
  },

  async listActiveSessions() {
    return account.listSessions(); // useful for a "Manage devices" settings screen
  },

  async logout() {
    return account.deleteSession('current');
  },

  async logoutEverywhere() {
    return account.deleteSessions();
  }
};

/* Creates the user's profile document the first time they sign up.
   Exported on window so profile.js can also call it defensively (self-healing
   for any account — old or new — that somehow still has no profile doc). */
async function ensureProfileDocument(userId, displayName) {
  try {
    await databases.getDocument(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.PROFILES, userId);
  } catch (err) {
    // No profile yet — create one. Document ID = user ID keeps a 1:1 mapping.
    await databases.createDocument(
      APPWRITE_CONFIG.DATABASE_ID,
      APPWRITE_CONFIG.COLLECTIONS.PROFILES,
      userId,
      { displayName: displayName || "New User", avatarFileId: null, bio: "" },
      [Permission.read(Role.any()), Permission.update(Role.user(userId))]
    );
  }
}
window.ensureProfileDocument = ensureProfileDocument;

window.ShortTubeAuth = ShortTubeAuth;
