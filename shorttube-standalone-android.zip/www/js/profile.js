/* =====================================================================
   profile.js — Edit Profile + Follow system + social stats
   ---------------------------------------------------------------------
   Depends on appwrite-config.js and auth.js being loaded first.

   HTML hooks this expects to exist in index.html (see html-injections.html
   for the exact markup to paste in):
     #editProfileBtn        - opens the edit modal
     #editProfileModal       - the modal itself
     #editNameInput          - text input for display name
     #editAvatarInput        - <input type="file" accept="image/*">
     #editAvatarPreview      - <img> preview
     #saveProfileBtn         - submit button
     #profileAvatarImg       - the avatar shown on the profile page itself
     #profileDisplayName     - the name shown on the profile page
     #statLikesVal / #statCommentsVal / #statFollowersVal
     #followBtn              - Follow / Following toggle button
===================================================================== */

const ShortTubeProfile = {

  /* ---------------- Load + render a profile ---------------- */
  async loadProfile(userId, viewingOwnProfile = true) {
    let doc;
    try {
      doc = await databases.getDocument(
        APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.PROFILES, userId
      );
    } catch (err) {
      // BUG FIX: any account that reached this point without a profile doc
      // (e.g. created directly in the Appwrite console, or via an older
      // build that only created docs on email/password signup) would
      // otherwise show a broken/blank profile forever. Self-heal by
      // creating a default doc now, then re-fetch it.
      console.warn('[ShortTube] No profile doc for', userId, '— creating a default one.', err);
      const me = viewingOwnProfile ? await ShortTubeAuth.getCurrentUser() : null;
      await window.ensureProfileDocument(userId, me?.name || "ShortTube User");
      doc = await databases.getDocument(
        APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.PROFILES, userId
      );
    }

    document.getElementById('profileDisplayName').textContent = doc.displayName;
    document.getElementById('profileAvatarImg').src = doc.avatarFileId
      ? storage.getFileView(APPWRITE_CONFIG.BUCKETS.AVATARS, doc.avatarFileId).href
      : 'logo.png'; // falls back to your brand logo, keeping the theme consistent

    const [likes, comments, followers] = await Promise.all([
      this.countLikesReceived(userId),
      this.countCommentsReceived(userId),
      this.countFollowers(userId)
    ]);
    document.getElementById('statLikesVal').textContent = likes;
    document.getElementById('statCommentsVal').textContent = comments;
    document.getElementById('statFollowersVal').textContent = followers;

    const followBtn = document.getElementById('followBtn');
    if (viewingOwnProfile) {
      followBtn.style.display = 'none';
    } else {
      followBtn.style.display = 'inline-flex';
      const me = await ShortTubeAuth.getCurrentUser();
      const isFollowing = me ? await this.isFollowing(me.$id, userId) : false;
      this.renderFollowButton(followBtn, isFollowing, userId);
    }
  },

  /* ---------------- Edit Profile (name + avatar) ---------------- */
  async saveProfileEdits(userId, newName, avatarFile) {
    const updates = { displayName: newName };

    if (avatarFile) {
      // Upload the new avatar to Appwrite Storage, then link its file ID on the profile doc
      const uploaded = await storage.createFile(
        APPWRITE_CONFIG.BUCKETS.AVATARS, ID.unique(), avatarFile,
        [Permission.read(Role.any()), Permission.update(Role.user(userId))]
      );
      updates.avatarFileId = uploaded.$id;
    }

    const updatedDoc = await databases.updateDocument(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.PROFILES, userId, updates
    );

    // Reflect the change immediately in the UI — no page reload needed
    document.getElementById('profileDisplayName').textContent = updatedDoc.displayName;
    if (updates.avatarFileId) {
      document.getElementById('profileAvatarImg').src =
        storage.getFileView(APPWRITE_CONFIG.BUCKETS.AVATARS, updates.avatarFileId).href;
    }
    return updatedDoc;
  },

  /* ---------------- Follow / Unfollow ---------------- */
  async isFollowing(followerId, followingId) {
    const res = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.FOLLOWS,
      [Query.equal('followerId', followerId), Query.equal('followingId', followingId)]
    );
    return res.documents.length > 0 ? res.documents[0] : false;
  },

  async follow(followerId, followingId) {
    return databases.createDocument(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.FOLLOWS, ID.unique(),
      { followerId, followingId },
      [Permission.read(Role.any()), Permission.delete(Role.user(followerId))]
    );
  },

  async unfollow(followDocId) {
    return databases.deleteDocument(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.FOLLOWS, followDocId);
  },

  renderFollowButton(btn, isFollowingDocOrFalse, targetUserId) {
    const setState = (following) => {
      btn.textContent = following ? "Following" : "Follow";
      btn.classList.toggle('following', !!following);
    };
    setState(isFollowingDocOrFalse);

    btn.onclick = async () => {
      const me = await ShortTubeAuth.getCurrentUser();
      if (!me) { alert("Please log in to follow creators."); return; }

      const current = await this.isFollowing(me.$id, targetUserId);
      btn.disabled = true;
      try {
        if (current) {
          await this.unfollow(current.$id);
          setState(false);
        } else {
          await this.follow(me.$id, targetUserId);
          setState(true);
        }
        const followerCount = await this.countFollowers(targetUserId);
        document.getElementById('statFollowersVal').textContent = followerCount;
      } finally {
        btn.disabled = false;
      }
    };
  },

  /* ---------------- Stat counters ---------------- */
  async countFollowers(userId) {
    const res = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.FOLLOWS,
      [Query.equal('followingId', userId), Query.limit(1)]
    );
    return res.total;
  },

  async countLikesReceived(userId) {
    // Likes on videos owned by this user. Requires videos to store ownerId,
    // and likes to store videoId — this does a two-step lookup.
    const videos = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.VIDEOS,
      [Query.equal('ownerId', userId), Query.limit(100)]
    );
    const videoIds = videos.documents.map(v => v.$id);
    if (videoIds.length === 0) return 0;
    const likes = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.LIKES,
      [Query.equal('videoId', videoIds), Query.limit(1)]
    );
    return likes.total;
  },

  async countCommentsReceived(userId) {
    const videos = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.VIDEOS,
      [Query.equal('ownerId', userId), Query.limit(100)]
    );
    const videoIds = videos.documents.map(v => v.$id);
    if (videoIds.length === 0) return 0;
    const comments = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.COMMENTS,
      [Query.equal('videoId', videoIds), Query.limit(1)]
    );
    return comments.total;
  },

  /* ---------------- Studio: views (used by the Studio analytics tab) ----------------
     A "view" is counted as one logged watch_events record (algorithm.js writes one
     each time a viewer finishes/pauses one of this user's uploaded videos). This is
     an approximation — good enough for a creator dashboard — not a strictly
     deduplicated unique-viewer count. */
  async countViewsReceived(userId) {
    const videos = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.VIDEOS,
      [Query.equal('ownerId', userId), Query.limit(100)]
    );
    const videoIds = videos.documents.map(v => v.$id);
    if (videoIds.length === 0) return 0;
    const views = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.WATCH_EVENTS,
      [Query.equal('videoId', videoIds), Query.limit(1)]
    );
    return views.total;
  },

  // Per-video breakdown for the Studio tab: views, likes, comments, and
  // moderation status for every video this user has uploaded.
  async getMyVideoStats(userId) {
    const videos = await databases.listDocuments(
      APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.VIDEOS,
      [Query.equal('ownerId', userId), Query.orderDesc('$createdAt'), Query.limit(50)]
    );
    return Promise.all(videos.documents.map(async (doc) => {
      const [viewsRes, likesRes, commentsRes] = await Promise.all([
        databases.listDocuments(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.WATCH_EVENTS, [Query.equal('videoId', doc.$id), Query.limit(1)]),
        databases.listDocuments(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.LIKES, [Query.equal('videoId', doc.$id), Query.limit(1)]),
        databases.listDocuments(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.COMMENTS, [Query.equal('videoId', doc.$id), Query.limit(1)])
      ]);
      return {
        id: doc.$id,
        title: doc.title,
        thumbnailUrl: doc.thumbnailFileId ? storage.getFileView(APPWRITE_CONFIG.BUCKETS.VIDEO_THUMBS, doc.thumbnailFileId).href : 'logo.png',
        views: viewsRes.total,
        likes: likesRes.total,
        comments: commentsRes.total,
        moderationStatus: doc.moderationStatus || 'live'
      };
    }));
  }
};

/* ---------------- Wire up the Edit Profile modal ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  const editBtn = document.getElementById('editProfileBtn');
  const modal = document.getElementById('editProfileModal');
  const nameInput = document.getElementById('editNameInput');
  const avatarInput = document.getElementById('editAvatarInput');
  const avatarPreview = document.getElementById('editAvatarPreview');
  const saveBtn = document.getElementById('saveProfileBtn');
  if (!editBtn) return; // markup not present on this page

  let pendingAvatarFile = null;

  editBtn.addEventListener('click', async () => {
    const me = await ShortTubeAuth.getCurrentUser();
    if (!me) { alert("Please log in first."); return; }
    nameInput.value = document.getElementById('profileDisplayName').textContent;
    avatarPreview.src = document.getElementById('profileAvatarImg').src;
    modal.classList.add('active');
  });

  avatarInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    pendingAvatarFile = file;
    avatarPreview.src = URL.createObjectURL(file);
  });

  saveBtn.addEventListener('click', async () => {
    const me = await ShortTubeAuth.getCurrentUser();
    if (!me) return;
    saveBtn.disabled = true;
    saveBtn.textContent = "Saving...";
    try {
      await ShortTubeProfile.saveProfileEdits(me.$id, nameInput.value.trim(), pendingAvatarFile);
      modal.classList.remove('active');
      pendingAvatarFile = null;
    } catch (err) {
      alert("Couldn't save profile: " + err.message);
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = "Save";
    }
  });
});

window.ShortTubeProfile = ShortTubeProfile;
