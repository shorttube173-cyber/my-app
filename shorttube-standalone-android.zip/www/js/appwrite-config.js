/* =====================================================================
   appwrite-config.js — Single shared Appwrite client
   ---------------------------------------------------------------------
   Your real Appwrite Endpoint + Project ID are inserted below. These are
   meant to be public (Appwrite enforces security via per-collection
   permissions, not by hiding this ID) — safe to ship in client code.
===================================================================== */

const APPWRITE_CONFIG = {
  ENDPOINT: "https://fra.cloud.appwrite.io/v1",
  PROJECT_ID: "shorttube",

  DATABASE_ID: "6a69384d083784998fb2",
  COLLECTIONS: {
    PROFILES: "profiles",
    VIDEOS: "videos",
    LIKES: "likes",
    COMMENTS: "comments",
    FOLLOWS: "follows",
    WATCH_EVENTS: "watch_events",
    REPORTS: "reports"
  },
  BUCKETS: {
    AVATARS: "avatars",
    VIDEO_THUMBS: "thumbnails",
    VIDEO_FILES: "videos"
  }
};

// NOTE: you still need to create the database, collections, and buckets
// above inside your Appwrite Console with these exact IDs — see
// APPWRITE_SETUP.md for the click-by-click steps. The config here just
// tells your app WHERE to look; it doesn't create anything by itself.

const { Client, Account, Databases, Storage, ID, Query, Permission, Role } = Appwrite;

const client = new Client()
  .setEndpoint(APPWRITE_CONFIG.ENDPOINT)
  .setProject(APPWRITE_CONFIG.PROJECT_ID);

const account = new Account(client);
const databases = new Databases(client);
const storage = new Storage(client);
