/* =====================================================================
   feed.js — Hybrid feed: YouTube + Appwrite uploads
   ---------------------------------------------------------------------
   STANDALONE APP VERSION: calls ShortTubeVideoAPI (js/video-api.js)
   directly, in-process, instead of fetching a Netlify serverless
   endpoint. There is no backend anymore — YouTube calls run
   straight from the WebView. See video-api.js for the security note
   about API keys now living client-side.

   Normalizes all three into the same shape your existing card renderers
   already expect:
     { id, source, title, thumbnail, embedUrl, channel, duration,
       viewCount, uploadedAt }
   — so createVideoCard()/createShortSlide() in index.html don't need to
   change their data-fetching. Just swap their data source to
   ShortTubeFeed.getHomeFeed() / getShortsFeed() instead of calling
   ShortTubeVideoAPI directly.

   STRICT SHORTS/LONG SEPARATION: a single shared rule decides category
   for EVERY source (Appwrite, YouTube) — not just uploads:
     - duration > 0 && duration <= SHORT_VIDEO_MAX_SECONDS  -> Shorts only
     - everything else (including unknown/0 duration, to be safe with
       older uploads or an API response missing duration) -> Home only
   This prevents the same clip from ever appearing as a landscape Home
   card AND a vertical Shorts slide.

   CONTENT-PREFERENCE FILTERING: onboarding (index.html) stores the
   user's chosen interests in localStorage under 'shorttube_preferences'
   (e.g. ["comedy","cooking"]). When present, those interests drive the
   actual search query sent to YouTube instead of a generic
   "trending" query, and Appwrite uploads are kept only when their
   title/description mentions one of the selected interests. This is a
   best-effort text match (the videos collection has no dedicated
   `category` attribute yet — see APPWRITE_SETUP.md for how to add one
   for exact matching instead of keyword matching).
===================================================================== */
const SHORT_VIDEO_MAX_SECONDS = 180;
function isShortForm(v) { return typeof v.duration === 'number' && v.duration > 0 && v.duration <= SHORT_VIDEO_MAX_SECONDS; }

// Maps each onboarding interest key to a richer set of search keywords so
// the external APIs return genuinely relevant results instead of just the
// bare category word.
const PREFERENCE_SEARCH_TERMS = {
  music: "music",
  gaming: "gaming gameplay",
  comedy: "comedy funny",
  tech: "tech technology review",
  sports: "sports highlights",
  vlogs: "vlog daily life",
  cooking: "cooking recipe",
  news: "news today"
};

let lastFeedSourceErrors = null;
const ShortTubeFeed = {

  /* ---------------- Interest preferences (from onboarding) ---------------- */
  getSelectedPreferences() {
    try {
      const raw = localStorage.getItem('shorttube_preferences');
      const prefs = raw ? JSON.parse(raw) : [];
      return Array.isArray(prefs) ? prefs : [];
    } catch { return []; }
  },

  // Builds the search string actually sent to ShortTubeVideoAPI. If the user picked
  // interests during onboarding, the feed is driven strictly by those —
  // otherwise it falls back to the generic default the caller passed in.
  buildQuery(defaultQuery) {
    const prefs = this.getSelectedPreferences();
    if (!prefs.length) return defaultQuery;
    const terms = prefs.map(p => PREFERENCE_SEARCH_TERMS[p] || p).join(' ');
    return terms;
  },

  // Best-effort check for whether an Appwrite upload matches the selected
  // interests, since the collection doesn't (yet) store a category field.
  matchesPreferences(video, prefs) {
    if (!prefs.length) return true;
    const haystack = `${video.title || ''} ${video._raw?.description || ''}`.toLowerCase();
    return prefs.some(p => {
      if (video._raw?.category && video._raw.category === p) return true; // exact match if the field exists
      const words = (PREFERENCE_SEARCH_TERMS[p] || p).toLowerCase().split(' ').concat(p);
      return words.some(w => haystack.includes(w));
    });
  },

  async fetchAppwriteVideos(limit = 25, offset = 0) {
    // DEBUG: log exactly which IDs are being sent, so a typo'd/incorrect
    // database or collection ID shows up immediately in the console.
    console.log('[ShortTube] fetchAppwriteVideos → calling listDocuments with',
      { databaseId: APPWRITE_CONFIG.DATABASE_ID, collectionId: APPWRITE_CONFIG.COLLECTIONS.VIDEOS, limit, offset });

    let res;
    try {
      res = await databases.listDocuments(
        APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.VIDEOS,
        [Query.orderDesc('$createdAt'), Query.limit(limit), Query.offset(offset)]
      );
      console.log('[ShortTube] listDocuments response:', res);
    } catch (err) {
      // Log the full Appwrite error (message/code/type/response) so the real
      // cause — bad ID, missing permission, no index, etc. — is visible,
      // then fail soft with an empty array instead of throwing. Throwing
      // here would previously reject the whole Promise.all in getHomeFeed()
      // and silently wipe out the YouTube results too.
      console.error('[ShortTube] listDocuments FAILED:', err);
      return [];
    }

    // Defensive check: handle a missing/empty response shape gracefully
    // instead of crashing on res.documents being undefined.
    const documents = Array.isArray(res?.documents) ? res.documents : [];
    if (documents.length === 0) {
      console.log('[ShortTube] Appwrite videos collection returned 0 documents (collection is empty or query matched nothing).');
      return [];
    }

    // MODERATION: never surface a video that automated/community moderation
    // has flagged. 'removed' = confirmed violation (taken down for good);
    // 'pending' = enough reports came in (or the upload-time checks flagged
    // it) that it's held out of feeds until a human reviews it. Videos with
    // no moderationStatus field yet (older uploads) are treated as clean.
    const clean = documents.filter(d => d.moderationStatus !== 'removed' && d.moderationStatus !== 'pending');

    // Ranks uploads by engagement score before they enter the merge,
    // so consistently well-watched uploads surface more often.
    const ranked = ShortTubeAlgorithm.rankByEngagement(clean);

    // Resolve owner display names in parallel (small batch, cached per session)
    const withOwners = await Promise.all(ranked.map(async (doc) => {
      const ownerName = await this._getCachedOwnerName(doc.ownerId);
      return {
        id: doc.$id,
        source: 'appwrite',
        title: doc.title,
        channel: ownerName,
        thumbnail: storage.getFileView(APPWRITE_CONFIG.BUCKETS.VIDEO_THUMBS, doc.thumbnailFileId).href,
        embedUrl: storage.getFileView(APPWRITE_CONFIG.BUCKETS.VIDEO_FILES, doc.videoFileId).href,
        duration: doc.durationSeconds,
        // engagementScore is the closest thing we track to a "view count"
        // for uploads (bumped on every watch — see algorithm.js)
        viewCount: doc.engagementScore || 0,
        uploadedAt: doc.createdAt || doc.$createdAt,
        ownerId: doc.ownerId,
        _raw: doc // kept around so player-enhancements.js / algorithm.js can log watch time
      };
    }));
    return withOwners;
  },

  _ownerNameCache: {},
  async _getCachedOwnerName(ownerId) {
    if (this._ownerNameCache[ownerId]) return this._ownerNameCache[ownerId];
    try {
      const profile = await databases.getDocument(APPWRITE_CONFIG.DATABASE_ID, APPWRITE_CONFIG.COLLECTIONS.PROFILES, ownerId);
      this._ownerNameCache[ownerId] = profile.displayName;
      return profile.displayName;
    } catch { return "ShortTube Creator"; }
  },

  shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  },

  /* ---------------- HOME (long-form) ----------------
     IMPORTANT: this now NEVER touches YouTube's Search API. It calls
     ShortTubeVideoAPI.getFeed({mode:'home'}), which hits
     videos.list?chart=mostPopular (1 quota unit) instead of search.list
     (100 quota units) — see video-api.js for the full explanation. Home
     is curated/trending content, not search results; it no longer takes
     a free-text query at all, only an optional `category` derived from
     onboarding preferences. */
  async getHomeFeed(page = 1) {
    const HOME_PAGE_SIZE = 25;
    const prefs = this.getSelectedPreferences();
    // Only pass a category when exactly one interest is selected — YouTube's
    // List API takes a single videoCategoryId, not a set, so multiple
    // preferences fall back to general PK trending rather than picking one
    // arbitrarily.
    const category = prefs.length === 1 ? prefs[0] : null;

    const [externalRes, appwriteVideos] = await Promise.all([
      ShortTubeVideoAPI.getFeed({ mode: 'home', page, category })
        .then(data => {
          lastFeedSourceErrors = data?.sourceErrors || null;
          if (data?.sourceErrors) console.error('[ShortTube] getFeed source errors (this is almost always why videos are missing):', data.sourceErrors);
          return data;
        })
        .catch((err) => { console.error('[ShortTube] getFeed(home) failed:', err); return { videos: [] }; }),
      // Infinite Scroll fix: page>1 must fetch the NEXT batch of uploads via
      // offset, not silently refetch the same first 25 every time — otherwise
      // "loading more" would show duplicates of what's already on screen.
      this.fetchAppwriteVideos(HOME_PAGE_SIZE, (page - 1) * HOME_PAGE_SIZE)
    ]);

    console.log('[ShortTube] getHomeFeed results:', { external: externalRes, appwriteCount: appwriteVideos.length });

    // Defensive: externalRes.videos could be missing/undefined if the
    // Netlify function returned an unexpected shape.
    const externalVideos = Array.isArray(externalRes?.videos) ? externalRes.videos : [];
    // Categorization: apply the SAME short/long rule to every source, so a
    // sub-3-minute YouTube clip can't leak into the long-form
    // Home feed any more than a short Appwrite upload can.
    const longExternal = externalVideos.filter(v => !isShortForm(v));
    const longUploads = appwriteVideos
      .filter(v => !isShortForm(v))
      .filter(v => this.matchesPreferences(v, prefs));
    const merged = this.shuffle([...longExternal, ...longUploads]);
    return merged; // Unity interstitial pacing happens in renderFeedItems()/observeShortsPlayback(), not here
  },

  /* ---------------- SHORTS ----------------
     Same List-API-only rule as Home: pulls from mode=home (mostPopular),
     then keeps only the sub-3-minute clips. This means Shorts may surface
     fewer external results than the old Search-API version did — that's
     the deliberate trade-off for not burning Search quota. Appwrite
     in-app uploads still fill out the feed alongside whatever qualifies. */
  async getShortsFeed(page = 1) {
    const prefs = this.getSelectedPreferences();
    const category = prefs.length === 1 ? prefs[0] : null;

    const [externalRes, appwriteVideos] = await Promise.all([
      ShortTubeVideoAPI.getFeed({ mode: 'home', page: Math.ceil(Math.random() * 5), category })
        .then(data => {
          lastFeedSourceErrors = data?.sourceErrors || null;
          if (data?.sourceErrors) console.error('[ShortTube] getFeed (shorts) source errors (this is almost always why videos are missing):', data.sourceErrors);
          return data;
        })
        .catch((err) => { console.error('[ShortTube] getFeed (shorts) failed:', err); return { videos: [] }; }),
      this.fetchAppwriteVideos() // never throws — returns [] on failure, see above
    ]);

    console.log('[ShortTube] getShortsFeed results:', { external: externalRes, appwriteCount: appwriteVideos.length });

    const externalVideos = Array.isArray(externalRes?.videos) ? externalRes.videos : [];
    // Same categorization rule as getHomeFeed, applied uniformly: only true
    // Shorts (0 < duration <= 180s) qualify, from ANY source.
    const shortExternal = externalVideos.filter(isShortForm);
    const shortUploads = appwriteVideos
      .filter(isShortForm)
      .filter(v => this.matchesPreferences(v, prefs));
    const merged = this.shuffle([...shortExternal, ...shortUploads]);
    return merged; // Unity interstitial pacing happens in observeShortsPlayback(), not here
  },

  /* ---------------- SEARCH ----------------
     The ONLY path in this app that hits YouTube's Search API (mode=search,
     100 quota units/call). Must only be called on an explicit user action
     (Enter / Search submit) — never on every keystroke. See index.html's
     search overlay wiring: the old per-keystroke debounce call was removed. */
  async getSearchResults(query, page = 1) {
    if (!query || !query.trim()) return [];
    const res = await ShortTubeVideoAPI.getFeed({ mode: 'search', query, page })
      .then(data => {
        lastFeedSourceErrors = data?.sourceErrors || null;
        if (data?.sourceErrors) console.error('[ShortTube] getFeed search source errors:', data.sourceErrors);
        return data;
      })
      .catch((err) => { console.error('[ShortTube] search failed:', err); return { videos: [] }; });
    const externalVideos = Array.isArray(res?.videos) ? res.videos : [];
    return this.shuffle(externalVideos);
  },

  async refreshHome() {
    if (typeof window.renderHomeFeedFromData === 'function') {
      const data = await this.getHomeFeed();
      window.renderHomeFeedFromData(data);
    }
  }
};

window.ShortTubeFeed = ShortTubeFeed;
window.getLastFeedSourceErrors = () => lastFeedSourceErrors;
